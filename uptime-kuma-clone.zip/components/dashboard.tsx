"use client"

import { useState, useEffect, useCallback } from "react"
import { Activity, RefreshCw, Bell, Settings, Clock, Globe } from "lucide-react"
import { SummaryCards } from "@/components/summary-cards"
import { ServiceTimeline } from "@/components/service-timeline"
import { UptimeBars } from "@/components/uptime-bars"
import { ResponseTimeChart } from "@/components/response-time-chart"
import { MonitorTable } from "@/components/monitor-table"
import { IncidentFeed } from "@/components/incident-feed"
import {
  generateServices,
  generateMonitors,
  generateLocationUptimes,
  generateResponseTimeData,
  generateIncidents,
} from "@/lib/monitoring-data"

export function Dashboard() {
  const [services, setServices] = useState(generateServices)
  const [monitors, setMonitors] = useState(generateMonitors)
  const [locations, setLocations] = useState(generateLocationUptimes)
  const [responseData, setResponseData] = useState(generateResponseTimeData)
  const [incidents] = useState(generateIncidents)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [autoRefresh, setAutoRefresh] = useState(true)

  const refresh = useCallback(() => {
    setIsRefreshing(true)
    setTimeout(() => {
      setServices(generateServices())
      setMonitors(generateMonitors())
      setLocations(generateLocationUptimes())
      setResponseData(generateResponseTimeData())
      setLastUpdated(new Date())
      setIsRefreshing(false)
    }, 500)
  }, [])

  useEffect(() => {
    if (!autoRefresh) return
    const interval = setInterval(refresh, 30000)
    return () => clearInterval(interval)
  }, [autoRefresh, refresh])

  const allOperational = services.every(s => s.status === "operational")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-base font-bold tracking-tight text-foreground">StatusPulse</h1>
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Monitoring Dashboard</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-lg border border-border bg-secondary px-3 py-1.5 sm:flex">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                Updated {lastUpdated.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </span>
            </div>

            <button
              onClick={() => setAutoRefresh(p => !p)}
              className={`rounded-lg border p-2 transition-colors ${
                autoRefresh
                  ? "border-primary/30 bg-primary/10 text-primary"
                  : "border-border bg-secondary text-muted-foreground hover:text-foreground"
              }`}
              aria-label={autoRefresh ? "Disable auto-refresh" : "Enable auto-refresh"}
              title={autoRefresh ? "Auto-refresh: ON (30s)" : "Auto-refresh: OFF"}
            >
              <Globe className="h-4 w-4" />
            </button>

            <button
              onClick={refresh}
              disabled={isRefreshing}
              className="rounded-lg border border-border bg-secondary p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:opacity-50"
              aria-label="Refresh data"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            </button>

            <button
              className="rounded-lg border border-border bg-secondary p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
            </button>

            <button
              className="rounded-lg border border-border bg-secondary p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              aria-label="Settings"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      {/* System status banner */}
      <div
        className={`border-b ${
          allOperational
            ? "border-[var(--status-operational)]/20 bg-[var(--status-operational)]/5"
            : "border-[var(--status-minor)]/20 bg-[var(--status-minor)]/5"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center gap-2 px-4 py-2 sm:px-6">
          <div
            className={`h-2 w-2 rounded-full ${
              allOperational ? "bg-[var(--status-operational)] animate-pulse" : "bg-[var(--status-minor)]"
            }`}
          />
          <p
            className={`text-xs font-medium ${
              allOperational ? "text-[var(--status-operational)]" : "text-[var(--status-minor)]"
            }`}
          >
            {allOperational
              ? "All systems operational"
              : "Some systems are experiencing issues"}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
        {/* Summary Stats */}
        <SummaryCards monitors={monitors} />

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          <UptimeBars locations={locations} />
          <ResponseTimeChart data={responseData} />
        </div>

        {/* 90-Day Timeline */}
        <ServiceTimeline services={services} />

        {/* Bottom Section */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <MonitorTable monitors={monitors} />
          </div>
          <div>
            <IncidentFeed incidents={incidents} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <p className="text-xs text-muted-foreground">
            StatusPulse Monitoring Dashboard
          </p>
          <div className="flex items-center gap-1.5">
            <div className="h-1.5 w-1.5 rounded-full bg-[var(--status-operational)] animate-pulse" />
            <span className="text-xs text-muted-foreground">
              {autoRefresh ? "Live" : "Paused"}
            </span>
          </div>
        </div>
      </footer>
    </div>
  )
}
