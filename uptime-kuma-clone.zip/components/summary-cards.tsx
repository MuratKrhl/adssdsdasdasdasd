"use client"

import { Activity, ArrowDown, ArrowUp, Pause, Server } from "lucide-react"
import type { Monitor } from "@/lib/monitoring-data"

interface SummaryCardsProps {
  monitors: Monitor[]
}

export function SummaryCards({ monitors }: SummaryCardsProps) {
  const up = monitors.filter(m => m.status === "up").length
  const down = monitors.filter(m => m.status === "down").length
  const paused = monitors.filter(m => m.status === "paused").length
  const all = monitors.length

  const cards = [
    { label: "Down", value: down, icon: ArrowDown, color: "text-[var(--status-major)]", bgColor: "bg-[var(--status-major)]/10" },
    { label: "Up", value: up, icon: ArrowUp, color: "text-[var(--status-operational)]", bgColor: "bg-[var(--status-operational)]/10" },
    { label: "Paused", value: paused, icon: Pause, color: "text-muted-foreground", bgColor: "bg-muted/50" },
    { label: "All", value: all, icon: Server, color: "text-foreground", bgColor: "bg-secondary" },
  ]

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {cards.map(card => (
        <div
          key={card.label}
          className="group relative overflow-hidden rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-3xl font-bold tracking-tight font-mono ${card.color}`}>
                {card.value}
              </p>
              <p className="mt-1 text-xs font-medium uppercase tracking-widest text-muted-foreground">
                {card.label}
              </p>
            </div>
            <div className={`rounded-lg p-2.5 ${card.bgColor}`}>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 h-0.5 w-full opacity-0 transition-opacity group-hover:opacity-100">
            <div className={`h-full w-full ${card.color === "text-foreground" ? "bg-foreground/20" : card.color.replace("text-", "bg-")}`} />
          </div>
        </div>
      ))}
    </div>
  )
}
