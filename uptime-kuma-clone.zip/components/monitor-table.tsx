"use client"

import { useState, useMemo } from "react"
import {
  Search,
  ArrowUpDown,
  ExternalLink,
  Pause,
  Play,
  Pencil,
  Trash2,
  Zap,
  Shield,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import type { Monitor, MonitorStatus, MonitorType } from "@/lib/monitoring-data"
import { getMonitorStatusColor } from "@/lib/monitoring-data"

interface MonitorTableProps {
  monitors: Monitor[]
}

type SortKey = "status" | "type" | "name" | "domain" | "uptime" | "lastChecked"
type SortDir = "asc" | "desc"

const statusOrder: Record<MonitorStatus, number> = { down: 0, up: 1, paused: 2 }

export function MonitorTable({ monitors }: MonitorTableProps) {
  const [search, setSearch] = useState("")
  const [locationFilter, setLocationFilter] = useState("")
  const [sortKey, setSortKey] = useState<SortKey>("status")
  const [sortDir, setSortDir] = useState<SortDir>("asc")
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  const locations = useMemo(
    () => [...new Set(monitors.map(m => m.location))].sort(),
    [monitors]
  )

  const filtered = useMemo(() => {
    let result = monitors
    if (search) {
      const s = search.toLowerCase()
      result = result.filter(
        m =>
          m.name.toLowerCase().includes(s) ||
          m.domain.toLowerCase().includes(s) ||
          m.type.toLowerCase().includes(s)
      )
    }
    if (locationFilter) {
      result = result.filter(m => m.location === locationFilter)
    }
    return result.sort((a, b) => {
      let cmp = 0
      switch (sortKey) {
        case "status":
          cmp = statusOrder[a.status] - statusOrder[b.status]
          break
        case "type":
          cmp = a.type.localeCompare(b.type)
          break
        case "name":
          cmp = a.name.localeCompare(b.name)
          break
        case "domain":
          cmp = a.domain.localeCompare(b.domain)
          break
        case "uptime":
          cmp = a.uptime - b.uptime
          break
        case "lastChecked":
          cmp = new Date(a.lastChecked).getTime() - new Date(b.lastChecked).getTime()
          break
      }
      return sortDir === "asc" ? cmp : -cmp
    })
  }, [monitors, search, locationFilter, sortKey, sortDir])

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(d => (d === "asc" ? "desc" : "asc"))
    } else {
      setSortKey(key)
      setSortDir("asc")
    }
  }

  const toggleAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(filtered.map(m => m.id)))
    }
  }

  const toggleOne = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortKey !== column) return <ArrowUpDown className="ml-1 h-3 w-3 text-muted-foreground/50" />
    return sortDir === "asc" ? (
      <ChevronUp className="ml-1 h-3 w-3 text-primary" />
    ) : (
      <ChevronDown className="ml-1 h-3 w-3 text-primary" />
    )
  }

  const formatTime = (iso: string) => {
    return new Date(iso).toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    })
  }

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border px-5 py-4">
        <h2 className="text-sm font-semibold text-foreground">Monitor Checks</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {filtered.length} of {monitors.length} monitors
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Type here to filter..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="h-9 w-full rounded-lg border border-border bg-secondary pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <select
          value={locationFilter}
          onChange={e => setLocationFilter(e.target.value)}
          className="h-9 rounded-lg border border-border bg-secondary px-3 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        >
          <option value="">All Locations</option>
          {locations.map(loc => (
            <option key={loc} value={loc}>{loc}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
              <th className="w-10 py-3 pl-4 pr-2">
                <input
                  type="checkbox"
                  checked={selectedIds.size === filtered.length && filtered.length > 0}
                  onChange={toggleAll}
                  className="h-3.5 w-3.5 rounded border-border accent-primary"
                />
              </th>
              {([
                { key: "status" as SortKey, label: "Status", width: "w-24" },
                { key: "type" as SortKey, label: "Type", width: "w-16" },
                { key: "name" as SortKey, label: "Name", width: "" },
                { key: "domain" as SortKey, label: "Domain", width: "" },
                { key: "uptime" as SortKey, label: "Uptime", width: "w-40" },
                { key: "lastChecked" as SortKey, label: "Last Ran At", width: "w-48" },
              ] as const).map(col => (
                <th
                  key={col.key}
                  className={`cursor-pointer py-3 px-3 text-left font-semibold ${col.width}`}
                  onClick={() => toggleSort(col.key)}
                >
                  <span className="inline-flex items-center">
                    {col.label}
                    <SortIcon column={col.key} />
                  </span>
                </th>
              ))}
              <th className="w-32 py-3 px-3 text-right">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map(monitor => (
              <tr
                key={monitor.id}
                className={`group transition-colors hover:bg-accent/30 ${selectedIds.has(monitor.id) ? "bg-accent/20" : ""}`}
              >
                <td className="py-3 pl-4 pr-2">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(monitor.id)}
                    onChange={() => toggleOne(monitor.id)}
                    className="h-3.5 w-3.5 rounded border-border accent-primary"
                  />
                </td>
                <td className="py-3 px-3">
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold uppercase ${
                      monitor.status === "up"
                        ? "bg-[var(--status-operational)]/15 text-[var(--status-operational)]"
                        : monitor.status === "down"
                        ? "bg-[var(--status-major)]/15 text-[var(--status-major)]"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    <span className={`h-1.5 w-1.5 rounded-full ${getMonitorStatusColor(monitor.status)}`} />
                    {monitor.status === "up" ? "Pass" : monitor.status === "down" ? "Fail" : "Paused"}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <span className="rounded-md bg-secondary px-2 py-0.5 text-xs font-mono font-medium text-muted-foreground">
                    {monitor.type}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <span className="text-sm font-medium text-primary hover:underline cursor-pointer">
                    {monitor.name}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <span className="text-xs text-muted-foreground font-mono">{monitor.domain}</span>
                </td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    {monitor.sslDaysLeft !== undefined ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[var(--status-operational)]/15 px-2.5 py-1 text-xs font-semibold text-[var(--status-operational)]">
                        <Shield className="h-3 w-3" />
                        {monitor.sslDaysLeft} days to go
                      </span>
                    ) : (
                      <>
                        <span className="text-xs font-mono font-semibold text-foreground">
                          {monitor.uptime}%
                        </span>
                        <div className="h-1.5 w-20 overflow-hidden rounded-full bg-secondary">
                          <div
                            className="h-full rounded-full bg-[var(--status-operational)] transition-all"
                            style={{ width: `${monitor.uptime}%` }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                </td>
                <td className="py-3 px-3">
                  <span className="text-xs text-muted-foreground">
                    {formatTime(monitor.lastChecked)}
                  </span>
                </td>
                <td className="py-3 px-3">
                  <div className="flex items-center justify-end gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    {[Pause, Zap, Pencil, Trash2].map((Icon, i) => (
                      <button
                        key={i}
                        className="rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                        aria-label={Icon.displayName || "action"}
                      >
                        <Icon className="h-3.5 w-3.5" />
                      </button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
