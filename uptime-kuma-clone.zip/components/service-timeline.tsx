"use client"

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { Service, ServiceStatus } from "@/lib/monitoring-data"
import { getStatusColor, getStatusTextColor } from "@/lib/monitoring-data"

interface ServiceTimelineProps {
  services: Service[]
}

const statusLabels: Record<ServiceStatus, string> = {
  operational: "Operational",
  degraded: "Degraded",
  minor: "Minor Incident",
  major: "Major Incident",
  maintenance: "Maintenance",
}

export function ServiceTimeline({ services }: ServiceTimelineProps) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <div>
          <h2 className="text-sm font-semibold text-foreground">Last 90 Days Uptime</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">Service availability over the past quarter</p>
        </div>
        <div className="flex items-center gap-4">
          {(["operational", "maintenance", "minor", "major", "degraded"] as ServiceStatus[]).map(status => (
            <div key={status} className="flex items-center gap-1.5">
              <div className={`h-2.5 w-2.5 rounded-full ${getStatusColor(status)}`} />
              <span className="text-xs text-muted-foreground">{statusLabels[status]}</span>
            </div>
          ))}
        </div>
      </div>

      <TooltipProvider delayDuration={100}>
        <div className="divide-y divide-border">
          {services.map(service => (
            <div key={service.id} className="group flex items-center gap-4 px-5 py-3 transition-colors hover:bg-accent/30">
              <div className="w-40 shrink-0">
                <p className="truncate text-sm font-medium text-foreground">{service.name}</p>
              </div>

              <div className="flex flex-1 items-center gap-px">
                {service.timeline.map((status, i) => (
                  <Tooltip key={i}>
                    <TooltipTrigger asChild>
                      <div
                        className={`h-7 flex-1 rounded-sm transition-all hover:scale-y-125 ${getStatusColor(status)} ${status === "operational" ? "opacity-80 hover:opacity-100" : "opacity-90 hover:opacity-100"}`}
                      />
                    </TooltipTrigger>
                    <TooltipContent side="top" className="bg-popover text-popover-foreground border-border">
                      <p className="text-xs font-medium">{statusLabels[status]}</p>
                      <p className="text-xs text-muted-foreground">{90 - i} days ago</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>

              <div className="w-24 text-right">
                <span className={`text-sm font-semibold font-mono ${getStatusTextColor(service.status)}`}>
                  {service.uptime}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </TooltipProvider>
    </div>
  )
}
