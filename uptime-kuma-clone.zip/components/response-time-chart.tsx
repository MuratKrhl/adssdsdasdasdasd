"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import type { ResponseTimeData } from "@/lib/monitoring-data"

interface ResponseTimeChartProps {
  data: ResponseTimeData[]
}

const locationColors: Record<string, string> = {
  london: "#22d3ee",
  singapore: "#c084fc",
  sanFrancisco: "#f97316",
  frankfurt: "#10b981",
  newYork: "#eab308",
}

const locationLabels: Record<string, string> = {
  london: "London, UK",
  singapore: "Singapore",
  sanFrancisco: "San Francisco, USA",
  frankfurt: "Frankfurt, Germany",
  newYork: "New York, USA",
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-xl">
      <p className="mb-1.5 text-xs font-medium text-foreground">{label}</p>
      {payload.map((entry: any) => (
        <div key={entry.dataKey} className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-xs text-muted-foreground">{locationLabels[entry.dataKey]}:</span>
          <span className="text-xs font-semibold font-mono text-foreground">{Math.round(entry.value)}ms</span>
        </div>
      ))}
    </div>
  )
}

export function ResponseTimeChart({ data }: ResponseTimeChartProps) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border px-5 py-4">
        <h2 className="text-sm font-semibold text-foreground">Response Time</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">Average latency by monitoring location</p>
      </div>
      <div className="p-4">
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 10, fill: "var(--muted-foreground)" }}
              tickLine={false}
              axisLine={{ stroke: "var(--border)" }}
              interval={Math.floor(data.length / 6)}
            />
            <YAxis
              tick={{ fontSize: 10, fill: "var(--muted-foreground)" }}
              tickLine={false}
              axisLine={{ stroke: "var(--border)" }}
              tickFormatter={(v) => `${v}ms`}
              width={55}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }}
              formatter={(value: string) => (
                <span className="text-muted-foreground">{locationLabels[value] || value}</span>
              )}
            />
            {Object.entries(locationColors).map(([key, color]) => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={color}
                strokeWidth={1.5}
                dot={false}
                activeDot={{ r: 3, strokeWidth: 0 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
