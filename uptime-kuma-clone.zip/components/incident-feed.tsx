"use client"

import { AlertTriangle, Wrench, AlertCircle, CheckCircle, MinusCircle } from "lucide-react"
import type { IncidentEvent, ServiceStatus } from "@/lib/monitoring-data"
import { getStatusColor } from "@/lib/monitoring-data"

interface IncidentFeedProps {
  incidents: IncidentEvent[]
}

const statusIcons: Record<ServiceStatus, typeof AlertTriangle> = {
  operational: CheckCircle,
  degraded: MinusCircle,
  minor: AlertTriangle,
  major: AlertCircle,
  maintenance: Wrench,
}

const statusLabels: Record<ServiceStatus, string> = {
  operational: "Resolved",
  degraded: "Degraded",
  minor: "Minor",
  major: "Major",
  maintenance: "Maintenance",
}

export function IncidentFeed({ incidents }: IncidentFeedProps) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border px-5 py-4">
        <h2 className="text-sm font-semibold text-foreground">Recent Incidents</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">Latest events across all services</p>
      </div>

      <div className="divide-y divide-border">
        {incidents.map(incident => {
          const Icon = statusIcons[incident.status]
          return (
            <div key={incident.id} className="group px-5 py-4 transition-colors hover:bg-accent/20">
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 rounded-lg p-1.5 ${getStatusColor(incident.status)}/15`}>
                  <Icon
                    className={`h-4 w-4 ${
                      incident.status === "operational"
                        ? "text-[var(--status-operational)]"
                        : incident.status === "maintenance"
                        ? "text-[var(--status-maintenance)]"
                        : incident.status === "minor"
                        ? "text-[var(--status-minor)]"
                        : incident.status === "major"
                        ? "text-[var(--status-major)]"
                        : "text-[var(--status-degraded)]"
                    }`}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-medium text-foreground truncate">{incident.title}</h3>
                    <span
                      className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                        incident.status === "operational"
                          ? "bg-[var(--status-operational)]/15 text-[var(--status-operational)]"
                          : incident.status === "maintenance"
                          ? "bg-[var(--status-maintenance)]/15 text-[var(--status-maintenance)]"
                          : incident.status === "minor"
                          ? "bg-[var(--status-minor)]/15 text-[var(--status-minor)]"
                          : incident.status === "major"
                          ? "bg-[var(--status-major)]/15 text-[var(--status-major)]"
                          : "bg-[var(--status-degraded)]/15 text-[var(--status-degraded)]"
                      }`}
                    >
                      {statusLabels[incident.status]}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{incident.description}</p>
                  <div className="mt-2 flex items-center gap-3">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground/70">
                      {incident.service}
                    </span>
                    <span className="text-[10px] text-muted-foreground/50">|</span>
                    <span className="text-[10px] text-muted-foreground/70">{incident.date}</span>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
