"use client"

import type { LocationUptime } from "@/lib/monitoring-data"

interface UptimeBarsProps {
  locations: LocationUptime[]
}

export function UptimeBars({ locations }: UptimeBarsProps) {
  const globalUptime = parseFloat(
    (locations.reduce((s, l) => s + l.uptime, 0) / locations.length).toFixed(2)
  )

  const allLocations = [...locations, { name: "Global Uptime", uptime: globalUptime, history: [] }]

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border px-5 py-4">
        <h2 className="text-sm font-semibold text-foreground">Uptime by Location</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">Regional availability over the past 30 days</p>
      </div>

      <div className="space-y-3 p-5">
        {allLocations.map(loc => {
          const width = Math.max(0, (loc.uptime - 95) * 20)
          const isGlobal = loc.name === "Global Uptime"

          return (
            <div key={loc.name} className="group">
              <div className="flex items-center gap-4">
                <span className={`w-28 shrink-0 text-xs font-medium ${isGlobal ? "text-foreground" : "text-muted-foreground"}`}>
                  {loc.name}
                </span>
                <div className="relative flex-1 h-6 overflow-hidden rounded-md bg-secondary">
                  <div
                    className="h-full rounded-md bg-[var(--status-operational)] transition-all duration-700 ease-out"
                    style={{ width: `${width}%` }}
                  />
                  {/* Segmented look */}
                  {loc.history.length > 0 && (
                    <div className="absolute inset-0 flex">
                      {loc.history.map((h, i) => (
                        <div
                          key={i}
                          className="flex-1 border-r border-card/30 last:border-r-0"
                          style={{
                            backgroundColor: h.uptime < 99
                              ? "var(--status-minor)"
                              : h.uptime < 99.5
                              ? "var(--status-degraded)"
                              : "var(--status-operational)",
                            opacity: 0.85,
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
                <span className={`w-16 text-right text-sm font-semibold font-mono ${
                  loc.uptime >= 99.9
                    ? "text-[var(--status-operational)]"
                    : loc.uptime >= 99
                    ? "text-[var(--status-degraded)]"
                    : "text-[var(--status-minor)]"
                }`}>
                  {loc.uptime}%
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
