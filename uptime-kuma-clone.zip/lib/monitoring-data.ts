export type ServiceStatus = "operational" | "degraded" | "minor" | "major" | "maintenance"
export type MonitorStatus = "up" | "down" | "paused"
export type MonitorType = "HTTP" | "HTTPS" | "TCP" | "PING" | "DNS" | "SSL" | "API"

export interface Service {
  id: string
  name: string
  status: ServiceStatus
  uptime: number
  timeline: ServiceStatus[]
}

export interface Monitor {
  id: string
  name: string
  type: MonitorType
  domain: string
  status: MonitorStatus
  uptime: number
  responseTime: number
  lastChecked: string
  location: string
  sslDaysLeft?: number
}

export interface LocationUptime {
  name: string
  uptime: number
  history: { date: string; uptime: number }[]
}

export interface ResponseTimeData {
  time: string
  london: number
  singapore: number
  sanFrancisco: number
  frankfurt: number
  newYork: number
}

export interface IncidentEvent {
  id: string
  title: string
  status: ServiceStatus
  date: string
  description: string
  service: string
}

function generateTimeline(days: number): ServiceStatus[] {
  const statuses: ServiceStatus[] = ["operational", "maintenance", "minor", "major", "degraded"]
  const weights = [0.82, 0.06, 0.05, 0.03, 0.04]
  return Array.from({ length: days }, () => {
    const r = Math.random()
    let cumulative = 0
    for (let i = 0; i < weights.length; i++) {
      cumulative += weights[i]
      if (r <= cumulative) return statuses[i]
    }
    return "operational"
  })
}

export function generateServices(): Service[] {
  const names = [
    "API Gateway",
    "Authentication",
    "Database Cluster",
    "CDN / Edge Network",
    "Storage Service",
    "Webhook Delivery",
    "Search Engine",
    "Email Service",
    "Payment Processing",
    "CI/CD Pipeline",
    "DNS Resolution",
    "Load Balancer",
  ]
  return names.map((name, i) => {
    const timeline = generateTimeline(90)
    const operational = timeline.filter(s => s === "operational").length
    return {
      id: `svc-${i}`,
      name,
      status: timeline[timeline.length - 1],
      uptime: parseFloat(((operational / timeline.length) * 100).toFixed(2)),
      timeline,
    }
  })
}

export function generateMonitors(): Monitor[] {
  const monitors: Omit<Monitor, "id" | "lastChecked">[] = [
    { name: "Main Website", type: "HTTPS", domain: "www.statuspulse.io", status: "up", uptime: 100, responseTime: 142, location: "San Francisco", sslDaysLeft: 89 },
    { name: "API Server", type: "API", domain: "api.statuspulse.io", status: "up", uptime: 99.98, responseTime: 87, location: "London" },
    { name: "Auth Service", type: "HTTPS", domain: "auth.statuspulse.io", status: "up", uptime: 99.95, responseTime: 203, location: "Frankfurt" },
    { name: "CDN Health", type: "HTTP", domain: "cdn.statuspulse.io", status: "up", uptime: 100, responseTime: 34, location: "Singapore" },
    { name: "Database Primary", type: "TCP", domain: "db-primary.internal:5432", status: "up", uptime: 99.99, responseTime: 12, location: "San Francisco" },
    { name: "Database Replica", type: "TCP", domain: "db-replica.internal:5432", status: "up", uptime: 99.97, responseTime: 15, location: "London" },
    { name: "Redis Cache", type: "TCP", domain: "redis.internal:6379", status: "up", uptime: 100, responseTime: 3, location: "San Francisco" },
    { name: "Email SMTP", type: "TCP", domain: "smtp.mailprovider.com:587", status: "up", uptime: 99.89, responseTime: 312, location: "New York" },
    { name: "Webhook Service", type: "HTTPS", domain: "hooks.statuspulse.io", status: "up", uptime: 99.92, responseTime: 178, location: "Frankfurt" },
    { name: "Search Cluster", type: "HTTPS", domain: "search.statuspulse.io", status: "up", uptime: 99.85, responseTime: 95, location: "London" },
    { name: "Storage S3", type: "HTTPS", domain: "s3.storage.statuspulse.io", status: "up", uptime: 100, responseTime: 67, location: "San Francisco" },
    { name: "Payment Gateway", type: "API", domain: "pay.statuspulse.io", status: "up", uptime: 99.99, responseTime: 234, location: "New York" },
    { name: "CI/CD Runner", type: "HTTPS", domain: "ci.statuspulse.io", status: "paused", uptime: 98.5, responseTime: 0, location: "Frankfurt" },
    { name: "Staging Server", type: "HTTP", domain: "staging.statuspulse.io", status: "paused", uptime: 97.2, responseTime: 0, location: "San Francisco" },
    { name: "DNS Monitor", type: "DNS", domain: "statuspulse.io", status: "up", uptime: 100, responseTime: 22, location: "London" },
    { name: "SSL Certificate", type: "SSL", domain: "www.statuspulse.io:443", status: "up", uptime: 100, responseTime: 156, location: "San Francisco", sslDaysLeft: 89 },
    { name: "Load Balancer", type: "TCP", domain: "lb.statuspulse.io:443", status: "up", uptime: 99.99, responseTime: 8, location: "Singapore" },
    { name: "Metrics API", type: "API", domain: "metrics.statuspulse.io", status: "up", uptime: 99.94, responseTime: 127, location: "Frankfurt" },
    { name: "Backup Service", type: "HTTPS", domain: "backup.statuspulse.io", status: "paused", uptime: 96.8, responseTime: 0, location: "New York" },
    { name: "Notification Hub", type: "HTTPS", domain: "notify.statuspulse.io", status: "up", uptime: 99.91, responseTime: 189, location: "London" },
    { name: "GraphQL Endpoint", type: "API", domain: "graphql.statuspulse.io", status: "up", uptime: 99.96, responseTime: 105, location: "San Francisco" },
  ]

  const now = new Date()
  return monitors.map((m, i) => ({
    ...m,
    id: `mon-${i}`,
    lastChecked: new Date(now.getTime() - Math.random() * 60000).toISOString(),
  }))
}

export function generateLocationUptimes(): LocationUptime[] {
  const locations = ["London", "Singapore", "San Francisco", "Frankfurt", "New York"]
  const days = 30
  return locations.map(name => {
    const baseUptime = 99 + Math.random()
    const history = Array.from({ length: days }, (_, i) => {
      const date = new Date()
      date.setDate(date.getDate() - (days - i))
      return {
        date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        uptime: Math.min(100, baseUptime + (Math.random() - 0.5) * 1.5),
      }
    })
    return {
      name,
      uptime: parseFloat((history.reduce((sum, h) => sum + h.uptime, 0) / history.length).toFixed(2)),
      history,
    }
  })
}

export function generateResponseTimeData(): ResponseTimeData[] {
  const data: ResponseTimeData[] = []
  const now = new Date()
  for (let i = 48; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 30 * 60000)
    data.push({
      time: time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      london: 180 + Math.random() * 80 + (Math.random() > 0.9 ? 200 : 0),
      singapore: 250 + Math.random() * 100 + (Math.random() > 0.9 ? 300 : 0),
      sanFrancisco: 80 + Math.random() * 40,
      frankfurt: 200 + Math.random() * 60 + (Math.random() > 0.95 ? 250 : 0),
      newYork: 120 + Math.random() * 50,
    })
  }
  return data
}

export function generateIncidents(): IncidentEvent[] {
  return [
    { id: "inc-1", title: "Elevated API latency in EU regions", status: "minor", date: "2 hours ago", description: "We are investigating increased response times for API requests routed through EU endpoints.", service: "API Gateway" },
    { id: "inc-2", title: "Scheduled maintenance: Database cluster upgrade", status: "maintenance", date: "5 hours ago", description: "Rolling update of database nodes to version 16.2. Expected completion in 2 hours.", service: "Database Cluster" },
    { id: "inc-3", title: "CDN cache purge delay", status: "degraded", date: "1 day ago", description: "Cache invalidation requests are experiencing delays of up to 5 minutes. Workaround available.", service: "CDN / Edge Network" },
    { id: "inc-4", title: "Email delivery failures resolved", status: "operational", date: "2 days ago", description: "The issue with failed email deliveries has been resolved. All queued messages have been processed.", service: "Email Service" },
    { id: "inc-5", title: "Search indexing backlog", status: "minor", date: "3 days ago", description: "New documents are taking longer than expected to appear in search results.", service: "Search Engine" },
  ]
}

export function getStatusColor(status: ServiceStatus): string {
  const map: Record<ServiceStatus, string> = {
    operational: "bg-[var(--status-operational)]",
    degraded: "bg-[var(--status-degraded)]",
    minor: "bg-[var(--status-minor)]",
    major: "bg-[var(--status-major)]",
    maintenance: "bg-[var(--status-maintenance)]",
  }
  return map[status]
}

export function getStatusTextColor(status: ServiceStatus): string {
  const map: Record<ServiceStatus, string> = {
    operational: "text-[var(--status-operational)]",
    degraded: "text-[var(--status-degraded)]",
    minor: "text-[var(--status-minor)]",
    major: "text-[var(--status-major)]",
    maintenance: "text-[var(--status-maintenance)]",
  }
  return map[status]
}

export function getMonitorStatusColor(status: MonitorStatus): string {
  const map: Record<MonitorStatus, string> = {
    up: "bg-[var(--status-operational)]",
    down: "bg-[var(--status-major)]",
    paused: "bg-muted-foreground",
  }
  return map[status]
}
